#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinythemes)
library(dslabs)
library(dplyr)
library(ggplot2)
library(RColorBrewer)
library(ggpubr)
library(tidyverse)
library(thematic)
library(ggdark)

# load data
load("bikedata_summarized.RData")
load("coviddata_final.RData")

# Defining Variable for x-axis labeling in the plots.
labels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
           "Sep", "Oct", "Nov", "Dec")
day_break <- c(1, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365)
shinyApp(
  ui <- fluidPage(
    # Style for sliders
    tags$style(HTML(".js-irs-0 .irs-single, .js-irs-0 .irs-bar-edge, .js-irs-0 .irs-bar {background: silver}")),
    tags$style(HTML(".js-irs-1 .irs-single, .js-irs-1 .irs-bar-edge, .js-irs-1 .irs-bar {background: silver}")),
    tags$style(HTML(".js-irs-2 .irs-single, .js-irs-2 .irs-bar-edge, .js-irs-2 .irs-bar {background: silver}")),
    tags$style(HTML(".js-irs-3 .irs-single, .js-irs-3 .irs-bar-edge, .js-irs-3 .irs-bar {background: silver}")),
    tags$style(HTML(".js-irs-4 .irs-single, .js-irs-4 .irs-bar-edge, .js-irs-4 .irs-bar {background: silver}")),
    
    theme = bslib::bs_theme(bootswatch = "darkly"),
    # App title
    titlePanel(h2("Analyzing Impact of Covid-19 and Weather on Daily Citibike Trips in NYC", align = "center")),
    br(),
    br(),
    tabsetPanel(
      tabPanel("Weather Impact",
               br(),
               
               p(h5("Weather can have massive impact on mobility. Here we analyze how different weather patterns impact number of 
                    daily trips. We have subsampled the data by 20. So, the values on y-axis representating seven-day rolling mean of daily citibike trips
                    are approximately 1/20 of actual daily rides. We find that when temprature is higher, people bike more, while when temprature is very low, usage of
                    citibike reduces. We also see that for the year 2020, the boxplot is wider since Covid-19 caused wide variation in mobility
                    independent of other factors like weather." )  ),
               br(),
               sidebarLayout(
                 sidebarPanel(
                   tags$style(".well {background-color:black;}"),
                   sliderInput("tempmax", "Day Maximum Temprature (Fahrenheit):",
                               min = 14, max = 100,
                               value = c(40, 80)),
                   
                   sliderInput("tempmin", "Day Minimum Temprature (Fahrenheit):",
                               min = 2, max = 90,
                               value = c(20,60)),
                   
                   sliderInput("windspeed", "Day Average Wind Speed (meters/sec):",
                               min = .9, max = 15,
                               value = c(0.9,10)),
                   
                   
                   sliderInput("rainfall", "Day Total Precipitation (inches):",
                               min = 0, max = 1,
                               value = c(0,0.2)),
                   
                   
                   
                 ),
                 
                 mainPanel(
                   tags$style(".well {background-color:black;}"),
                   plotOutput("boxplot")
                   
                 )
               )),
      tabPanel("Covid Impact",
               br(),
               p(h5("Covid-19 impacted mobility significantly in early stage of pandemic. Here we compare the number of trips for citibike across NYC for 2019 and 2020.
                    While number of citibike trips reduced drastically starting mid-March in 2020, it bounced back to pre-pandepmic level by July 2020. Note that we have
                    subsampled the data by 20. So, the values on y-axis representating seven-day rolling mean of daily citibike trips
                    are approximately 1/20 of actual daily rides."
                    )  ),
               
               br(),
               sidebarLayout(
                 sidebarPanel(
                   
                   
                   sliderInput("month_range", "Month Range:",
                               min = 1, max = 12,
                               value = c(1, 12))),
                 
                 
                 mainPanel(
                   plotOutput("linePlot", height = "250px", width = "100%"),
                   plotOutput("covidPlot", height = "250px", width = "100%")
                 )
                 
                 
               ))
    )),
  
  server <- function(input, output) {
    thematic::thematic_shiny()
    output$boxplot = renderPlot({
      
      # Making a box plot, with filters applied from slider inputs.
      bikedata_summarized %>% filter(AWND>=input$windspeed[1], AWND<=input$windspeed[2],PRCP>=input$rainfall[1],
                                     PRCP<=input$rainfall[2],TMAX>=input$tempmax[1], TMAX<=input$tempmax[2],
                                     TMIN>=input$tempmin[1], TMIN<=input$tempmin[2]) %>%ggplot(aes(as.factor(year),trips_7dayavg,group=as.factor(year)))+geom_boxplot(
                                       aes(fill=as.factor(year))) +coord_cartesian(ylim = c(0, 5000))+labs(
                                         x = "Year", y = "daily trips (7-day rolling mean)", color = "Year\n") +scale_color_manual(
                                           values = c("green", "red"))+theme(axis.text.x = element_text(angle = 90, hjust = 1)) +ggtitle(
                                             "Boxplot of Daily Trips Across 2019 and 2020")+theme(plot.title = element_text(hjust = 0.5))+dark_mode()+theme(
                                               legend.position = "none")+theme(text = element_text(size = 15))
    })
    output$linePlot = renderPlot({
      
      # Plotting Citibike ride patterns for 2019 and 2020 for months selected from slider input 
      ggplot(data = bikedata_summarized%>%filter(daynum<=day_break[input$month_range[2]+1], daynum>=day_break[input$month_range[1]]+1), aes(x = daynum, y = trips_7dayavg, group=as.factor(year)))+
        geom_line(aes(color=as.factor(year)))+
        labs(x = "Month", y = "daily trips (7-day rolling mean)", color = "Year\n") +
        scale_color_manual(values = c("green", "blue"))+
        scale_x_continuous(breaks=day_break[input$month_range[1]:input$month_range[2]], labels = labels[input$month_range[1]:input$month_range[2]])+
        scale_y_continuous(labels = scales::comma) +
        ggtitle (paste0("Trips in NYC between ", labels[input$month_range[1]],"-", labels[input$month_range[2]], " for 2020 and 2021"))+
        theme_light() +theme(plot.title = element_text(hjust = 0.5))+
        theme(panel.grid.minor = element_blank(),
              panel.grid.major = element_blank()
        )+dark_mode()+theme(text = element_text(size = 15))
      
    })
     output$covidPlot = renderPlot({
       
       # Plotting Covid-19 cases for months selected from slider input slider
       ggplot(data = coviddata_final%>%filter(daynum<=day_break[input$month_range[2]+1], daynum>=day_break[input$month_range[1]], year==2020), aes(x = daynum, y = case_7dayavg))+
         geom_line(aes(color=as.factor(year)))+
         labs(x = "Month", y = "daily cases (7-day rolling mean)", color = "Year\n")+
         scale_color_manual(values = c("red"))+
         scale_x_continuous(breaks=day_break[input$month_range[1]:input$month_range[2]], labels = labels[input$month_range[1]:input$month_range[2]])+
         scale_y_continuous(labels = scales::comma) +
         ggtitle (paste0("Covid Cases in NYC between ", labels[input$month_range[1]],"-", labels[input$month_range[2]], " for 2020"))+
         theme_light() +theme(plot.title = element_text(hjust = 0.5))+
         theme(panel.grid.minor = element_blank(),
               panel.grid.major = element_blank()
         )+dark_mode()+theme(text = element_text(size = 15))
       
       })
    
  })
